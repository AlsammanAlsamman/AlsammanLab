#!/usr/bin/python
from fastaHandeling import read
class Fasta:
    def __init__(self, filePath):
        self.filePath = filePath
        self.seqs = read(filePath)
        self.LengthInfo = self.calculateLength()
    
    def calculateLength(self):
        lengthInfo = {}
        for seqID in self.seqs:
            lengthInfo[seqID] = len(self.seqs[seqID])
        return lengthInfo
    
    def printSeqs(self):
        for seqID in self.seqs:
            print(seqID)
            print(self.seqs[seqID])


# using Fasta class
fasta = Fasta('sequence.fasta')
#fasta.printSeqs()
for seqID in fasta.LengthInfo:
    print(seqID, fasta.LengthInfo[seqID])