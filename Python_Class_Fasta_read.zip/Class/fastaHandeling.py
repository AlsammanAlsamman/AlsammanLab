def read(filePath):
    seqs = {}  # Dictionary to store sequences key is SeqID and value is sequence
    seqID=""
    with open(filePath) as f:
        for line in f:
            if line.startswith('>'):
                seqID = line.strip('>').strip()
                seqs[seqID] = ''
            else:
                seqs[seqID] += line.strip()
    return seqs